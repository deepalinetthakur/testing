package com.cg.elementlocator;

import org.openqa.selenium.By;

public class LocateElement 
{
	public static By adminId=By.xpath("//input[@ name='email']");
	public static By password=By.xpath("//input[@ name='password']");
	public static By admin=By.xpath("//label[@ for='customCheck3']");
	public static By signin=By.xpath("//button[@ class='btn btn-lg btn-primary btn-block text-uppercase']");
}
