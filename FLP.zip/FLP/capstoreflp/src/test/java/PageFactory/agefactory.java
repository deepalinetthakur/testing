
package PageFactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class agefactory {
	static WebDriver driver;
	public static void openbrowser(String url) {
		System.setProperty("webdriver.chrome.driver","./drivers/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
		System.out.println("browser opened");
		driver.manage().window().maximize();
		
	}

	
	
	public static void insertKeys(String val,By locator) {
		WebElement e=driver.findElement(locator);
		e.sendKeys(val);

	}
	
	public static void clearBox(By locator) {
		driver.findElement(locator).clear();
	}

	public static void clickmethod(By locatorforClick) throws InterruptedException {
		driver.findElement(locatorforClick).click();
		System.out.println(locatorforClick +"is clicked.");
		Thread.sleep(3000);
	}

	public static void close() {
		System.out.println("Closing the browser");
		driver.close();
	}

	public static void select(By locator) {
		WebElement e1=driver.findElement(locator);
		Select dd=new Select(e1);
		//dd.selectByVisibleText(val);
		dd.selectByIndex(1);
	//System.out.println("The value:"+val +" is selected from the dropdown");
	}
	
	public static void alertHandler() {
		driver.switchTo().alert().accept();
	}
	
	
}
