
package Locators;

import org.openqa.selenium.By;

public class ElementLocator {
	
	public static By signup=By.xpath("//a[text()='Sign Up']");
	public static By name=By.xpath("//input[@ type='text']");
	public static By email=By.xpath("//input[@ type='email']");
	public static By number=By.xpath("//input[@ placeholder='Phone number']");
	public static By customer=By.xpath("//select");
	public static By password=By.xpath("//input[@ type='password']");
	

	public static By cpassword=By.xpath("//input[@ placeholder='Confirm password']");
	public static By submit=By.xpath("//button[@ type='submit']");
	public static By login=By.xpath("//a[text()='Log In']");
	
	
			
}
